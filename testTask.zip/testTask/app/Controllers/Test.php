<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 9/29/2020
 * Time: 5:24 PM
 */

namespace App\Controllers;


use App\Models\Testmodel;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\Request;

class Test extends Controller
{
    public function index()
    {
         session();
        helper(['form', 'url']);
        $result= new Testmodel();
        $data = [
             'validation' => \Config\Services::validation(),
             'result' =>$result->getData()
        ];
          return view('index', $data);
     }

    public function formView()
    {
        session();
        helper(['form', 'url']);

        $data = [
            'validation' => \Config\Services::validation(),

        ];
         return view('addForm', $data);

     }

     public function addForm()
     {
          $session = session();
         helper(['form', 'url']);
          if (!$this->validate([
               'owner' => 'required',
               'identificator_nab' => 'required',
               'propertyType' => 'required',
               'country' => 'required',
               'street' => 'required',
               'city' => 'required',
               'state' => 'required',
               'postcode' => 'required',
               'starting_date' => 'required',
               'bedrooms' => 'required',
          ])) {

             return redirect()->to('formView')->withInput();
         }

         $slug="";
         $com=$this->request->getPost('compulsory_inclusions');
         if($com!=null)
         {
             $slug=implode(',',$com);

         }

          $test=new Testmodel();
          $test->save([
             'propertyType' => $this->request->getPost('propertyType'),
             'owner' => $this->request->getPost('owner'),
             'identificator_nab' => $this->request->getPost('identificator_nab'),
             'country' => $this->request->getPost('country'),
             'street' => $this->request->getPost('street'),
             'apt' =>  $this->request->getPost('apt'),
             'city' => $this->request->getPost('city'),
             'state' => $this->request->getPost('state'),
             'postcode' => $this->request->getPost('postcode'),
             'starting_date' => $this->request->getPost('starting_date'),
             'owner_stays' => $this->request->getPost('owner_stays'),
             'compulsory_inclusions' => $slug,
             'guests' => $this->request->getPost('guests'),
             'bedrooms' => $this->request->getPost('bedrooms'),
             'bathrooms' => $this->request->getPost('bathrooms'),
         ]);

          $propertyId=$test->insertID;
          $bedSpase=[
              'propertyId'=>$propertyId,
              'king'=>$this->request->getPost('king'),
              'queen'=>$this->request->getPost('queen'),
              'double_s'=>$this->request->getPost('double'),
              'single'=>$this->request->getPost('single'),
              'sofa'=>$this->request->getPost('sofa'),
              'bunk'=>$this->request->getPost('bunk'),
              'mates'=>$this->request->getPost('mate'),
              'couch'=>$this->request->getPost('couch'),
          ];

         $return= $test->insertData($bedSpase);
         if($return)
         {
             $session->setFlashdata('success', 'Data Inserted Successfully');

         }else{
             $session->setFlashdata('error', 'Please try again');

         }

         return redirect()->to('index');

     }

     public function deleteProperty($id=null)
     {
          $session = session();

         if($id!=null)
         {
             $test=new Testmodel();
             $return=$test->delete($id);


             if($return)
             {
                 $test->deleteBedSpace($id);
                 $session->setFlashdata('success', 'Data Deleted Successfully');

             }else{
                 $session->setFlashdata('error', 'Please try again');

             }
             return redirect()->to(base_url('Home'));

         }else{
             return redirect()->to(base_url('Home'));
         }
     }

     public function editForm($id=null)
     {
          $session = session();

         if($id!=null)
         {
             $test=new Testmodel();
             $return=$test->getDataSingle($id);
             session();
             helper(['form', 'url']);
              $data = [
                 'validation' => \Config\Services::validation(),
                 'result' => $return[0]
             ];
              return view('editForm', $data);




         }else{
             return redirect()->to(base_url('Home'));
         }

     }
     public function details($id=null)
     {
          $session = session();

         if($id!=null)
         {
             $test=new Testmodel();
             $return=$test->getDataSingle($id);
             session();
             helper(['form', 'url']);
              $data = [
                 'validation' => \Config\Services::validation(),
                 'result' => $return[0]
             ];
              return view('formDetails', $data);




         }else{
             return redirect()->to(base_url('Home'));
         }

     }

     public function updateForm()
     {
         $session = session();
         helper(['form', 'url']);
         if (!$this->validate([
             'owner' => 'required',
             'identificator_nab' => 'required',
             'propertyType' => 'required',
             'country' => 'required',
             'street' => 'required',
             'city' => 'required',
             'state' => 'required',
             'postcode' => 'required',
             'starting_date' => 'required',
             'bedrooms' => 'required',
         ])) {

             return redirect()->to('formView')->withInput();
         }

         $slug="";
         $com=$this->request->getPost('compulsory_inclusions');
         if($com!=null)
         {
             $slug=implode(',',$com);

         }

         $test=new Testmodel();
         $test->save([
             'propertyId' => $this->request->getPost('propertyId'),
             'propertyType' => $this->request->getPost('propertyType'),
             'owner' => $this->request->getPost('owner'),
             'identificator_nab' => $this->request->getPost('identificator_nab'),
             'country' => $this->request->getPost('country'),
             'street' => $this->request->getPost('street'),
             'apt' =>  $this->request->getPost('apt'),
             'city' => $this->request->getPost('city'),
             'state' => $this->request->getPost('state'),
             'postcode' => $this->request->getPost('postcode'),
             'starting_date' => $this->request->getPost('starting_date'),
             'owner_stays' => $this->request->getPost('owner_stays'),
             'compulsory_inclusions' => $slug,
             'guests' => $this->request->getPost('guests'),
             'bedrooms' => $this->request->getPost('bedrooms'),
             'bathrooms' => $this->request->getPost('bathrooms'),
         ]);

         $propertyId=$this->request->getPost('propertyId');
         $bedSpase=[
             'propertyId'=>$propertyId,
             'king'=>$this->request->getPost('king'),
             'queen'=>$this->request->getPost('queen'),
             'double_s'=>$this->request->getPost('double'),
             'single'=>$this->request->getPost('single'),
             'sofa'=>$this->request->getPost('sofa'),
             'bunk'=>$this->request->getPost('bunk'),
             'mates'=>$this->request->getPost('mate'),
             'couch'=>$this->request->getPost('couch'),
         ];

         $return= $test->updateBedSpace($bedSpase,$propertyId);
         if($return)
         {
             $session->setFlashdata('success', 'Data Updated Successfully');

         }else{
             $session->setFlashdata('error', 'Please try again');

         }

         return redirect()->to('index');


     }
}