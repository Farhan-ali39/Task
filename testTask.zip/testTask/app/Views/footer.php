
<script type="text/javascript" src="<?=base_url('public/js/custom.js')?>"></script>
<script type="text/javascript" src="<?=base_url('public/js/jquery.js')?>"></script>

</body>

</html>