<?php
include 'header.php';
$session = \Config\Services::session();
$session = session();

?>

<div class="container card">
    <?php if ($session->getFlashdata('error')) { ?>

        <div class="alert-danger" style="height: 50px;">
            <?php echo $session->getFlashdata('error'); ?>
            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>

        </div>
    <?php } ?>

    <?php if ($session->getFlashdata('success')) { ?>

        <div class="alert-success" style="height: 50px;">
            <?php echo $session->getFlashdata('success'); ?>
            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>

        </div>

    <?php } ?>

    <h2>Property Table</h2>
    <div class="row " >
        <a href="<?=base_url('Test/formView')?>" class="float-right btn btn-info">Add New</a>
    </div>
     <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>Owner</th>
            <th>Property Type</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Compulsory Inclusions</th>
            <th>Number of guests</th>
            <th>Bedrooms</th>
            <th>Bathrooms</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if(!empty($result))
        {
            foreach ($result as $item)
            {
                ?>
                <tr>
                    <td><?=$item['owner']?></td>
                    <td><?=ucfirst($item['propertyType'])?></td>
                    <td><?=$item['country']?></td>
                    <td><?=$item['state']?></td>
                    <td><?=$item['city']?></td>
                    <td><?=$item['compulsory_inclusions']?></td>
                    <td><?=$item['guests']?></td>
                    <td><?=$item['bedrooms']?></td>
                    <td><?=$item['bathrooms']?></td>
                    <td>
                        <a href="<?=base_url('Test/details/'.$item['propertyId'])?>"  class="btn btn-info">View</a>
                        <a href="<?=base_url('Test/editForm/'.$item['propertyId'])?>" class="btn btn-primary">Edit</a>
                        <a href="<?=base_url('Test/deleteProperty/'.$item['propertyId'])?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>

                <?php
            }
        }
        ?>
         </tbody>
    </table>
</div>
<?php
include 'footer.php';
?>
