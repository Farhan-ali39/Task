<?php
include 'header.php';
?>

<div class="container">

    <form class="form-horizontal" method="post" action="<?=base_url('Test/addForm')?>">
        <?= csrf_field(); ?>
        <?php
        $session = \Config\Services::session();
        $session = session();

//        echo  \Config\Services::validation()->listErrors();
        ?>
<!--        --><?php //echo $session->getFlashdata('flsh_msg'); ?>
        <div class="card">
            <a  href="<?=base_url()?>" class="btn btn-primary">Home Page</a>
            <div class="card-header">
                <h6>AIRKEEPER</h6>
            </div>
            <div class="card-body d-flex">

                <div class="form-group col-md-4">
                    <label for="">Owner</label>
                    <select class="form-control <?= ($validation->hasError('owner')) ? 'is-invalid' : ''; ?>" name="owner">
                        <option value="">Select Owner</option>
                        <option value="Owner 1" <?=set_select('owner',1)?>>Owner 1</option>
                        <option value="Owner 2" <?=set_select('owner',2)?>>Owner 2</option>
                        <option value="Owner 3" <?=set_select('owner',3)?>>Owner 3</option>

                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="">Identifier Airnab</label>
                    <input type="text" name="identificator_nab" value="<?= set_value('identificator_nab'); ?>"  placeholder="Promotional code" class="form-control <?= ($validation->hasError('identificator_nab')) ? 'is-invalid' : ''; ?>">
                </div>
                <div class="form-group col-md-4">
                    <label for="">Property Type</label>
                    <select class="form-control <?= ($validation->hasError('propertyType')) ? 'is-invalid' : ''; ?>" name="propertyType">

                        <option value="Apartment" <?=set_select('propertyType',"aprt")?>>Apartment</option>
                        <option value="House" <?=set_select('propertyType',"house")?>>House</option>
                        <option value="Town House" <?=set_select('propertyType',"town")?>>Town House</option>
                    </select>
                </div>

            </div>
         </div>
        <div class="card">
            <div class="card-header">
                <h6>Property Address</h6>
            </div>
            <div class="card-body  ">

                <div class="row">
                    <div class="form-group col-md-4">
                        <label for="">Country</label>
                        <select class="form-control <?= ($validation->hasError('country')) ? 'is-invalid' : ''; ?>" name="country">
                            <option value="">Select Country</option>
                            <option value="Australia">Australia</option>
                            <option value="China">China</option>
                            <option value="USA">USA</option>

                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="">Street Address</label>
                        <input type="text" name="street" value="<?= set_value('street'); ?>" placeholder="Street Address" class="form-control <?= ($validation->hasError('street')) ? 'is-invalid' : ''; ?>">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="">Apt,Suit(Optional)</label>
                        <input type="text" name="apt" placeholder="Apt,Suit(Optional)" class="form-control ">

                    </div>

                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <label for="">City</label>
                        <input type="text" name="city" value="<?= set_value('city'); ?>" placeholder="City" class="form-control <?= ($validation->hasError('city')) ? 'is-invalid' : ''; ?>">

                    </div>
                    <div class="form-group col-md-4">
                        <label for="">State</label>
                        <input type="text" name="state" value="<?= set_value('state'); ?>"  placeholder="State" class="form-control <?= ($validation->hasError('state')) ? 'is-invalid' : ''; ?>">

                    </div>
                    <div class="form-group col-md-4">
                        <label for="">Postcode</label>
                        <input type="text" name="postcode" value="<?= set_value('postcode'); ?>" placeholder="Postcode" class="form-control <?= ($validation->hasError('postcode')) ? 'is-invalid' : ''; ?>">

                    </div>

                </div>

            </div>
         </div>
        <div class="card col-md-6 float-left p-0" style="height: 250px;">
            <div class="card-header">
                <h6>Available</h6>
            </div>
            <div class="card-body">

                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="">Starting Date</label>
                        <input type="date" name="starting_date" value="<?= set_value('starting_date'); ?>" placeholder="Street Address" class="form-control <?= ($validation->hasError('starting_date')) ? 'is-invalid' : ''; ?>">
                    </div>
                    <div class="form-group col-md-4 mt-4">
                        <label for=""></label>
                        <label><input type="checkbox" name="owner_stays" >  Owner Stays</label>
                    </div>
                </div>

            </div>
        </div>
        <div class="card col-md-6 p-0" style="height: 250px;">
            <div class="card-header">
                <h6>Compulsory Inclusions</h6>
            </div>
            <div class="card-body">

                <div class="row">
                    <div class="form-group col-md-4">

                        <label><input type="checkbox" name="compulsory_inclusions[]" value="fire"> Fire Blanket $25</label>
                    </div>
                    <div class="form-group col-md-4">

                        <label><input type="checkbox" name="compulsory_inclusions[]" value="first"> First Aid Kit $15</label>
                    </div>
                    <div class="form-group col-md-4">

                        <label><input type="checkbox" name="compulsory_inclusions[]" value="smoke"> Smoke Detector $169 each</label>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">

                        <label><input type="checkbox" name="compulsory_inclusions[]" value="vacuum"> Vacuum $25</label>
                    </div>
                    <div class="form-group col-md-4">

                        <label><input type="checkbox" name="compulsory_inclusions[]" value="mop"> Mop $15</label>
                    </div>
                    <div class="form-group col-md-4">

                        <label><input type="checkbox" name="compulsory_inclusions[]" value="bucket"> Bucket $25</label>
                    </div>
                </div>
                <div class="row">
                    <p style="justify-content: center;font-size: 12px">* Please note any compulsry iclusion not selected as present will be provided by Airkeeper and charged at the rate listed</p>
                </div>

            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h6>Bed Configuration</h6>
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="form-group col-md-3">
                        <label for="">Number of Guests</label>
                        <div class="qty ">
                            <span class="minus bg-info guestMinus" id="guestMinus">-</span>

                            <input type="number" class="count guestCount" id="guestCount" name="guests"   value="0">
                            <span class="plus bg-info guestPlus" id="guestPlus">+</span>
                        </div>

                    </div>
                    <div class="form-group col-md-6">
                        <label for="">Number of Bedrooms</label>
                        <input type="text" name="bedrooms" value="<?= set_value('bedrooms'); ?>" placeholder="Number of Bedrooms" class="form-control <?= ($validation->hasError('starting_date')) ? 'is-invalid' : ''; ?>">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="">Number of Bathrooms</label>
                        <div class="qty ">
                            <span class="minus  bg-info" id="bathMinus">-</span>
                            <input type="number" class="count bathCount" id="bathCount" name="bathrooms" value="0">
                            <span class="plus bathPlus bg-info" id="bathPlus">+</span>
                        </div>
                    </div>
                </div>
                <h6>Common Space</h6>
                 <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">King</label>
                    <div class="qty ">
                        <span class="minus bg-info kingminus" id="kingminus">-</span>
                        <input type="number" class="count  " id="kingCount" name="king" value="0">
                        <span class="plus bg-info kingPlus" id="kingPlus">+</span>
                    </div>

                </div>
                <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">Queen</label>
                    <div class="qty ">
                        <span class="minus bg-info queenMinus" id="queenMinus">-</span>
                        <input type="number" class="count queenCount" id="queenCount" name="queen" value="0">
                        <span class="plus bg-info queenPlus" id="queenPlus">+</span>
                    </div>

                </div>
                <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">Double</label>
                    <div class="qty ">
                        <span class="minus bg-info doubleMinus" id="doubleMinus">-</span>
                        <input type="number" class="count doubleCount" id="doubleCount" name="double" value="0">
                        <span class="plus bg-info doublePlus" id="doublePlus">+</span>
                    </div>

                </div>
                <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">Single</label>

                    <div class="qty">
                        <span class="minus bg-info singleMinus" id="singleMinus">-</span>
                        <input type="number" class="count singleCount" id="singleCount" name="single" value="0">
                        <span class="plus bg-info singlePlus" id="singlePlus">+</span>


                    </div>
                </div>
                <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">Sofa</label>
                    <div class="qty ">
                        <span class="minus bg-info sofaMinus" id="sofaMinus">-</span>
                        <input type="number" class="count SofaCount" id="SofaCount" name="sofa" value="0">
                        <span class="plus bg-info sofaPlus" id="sofaPlus">+</span>
                    </div>

                </div>
                <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">Bunk</label>
                    <div class="qty ">
                        <span class="minus bg-info BunkMinus" id="BunkMinus">-</span>
                        <input type="number" class="count BunkCount" id="BunkCount" name="bunk" value="0">
                        <span class="plus bg-info BunkPlus" id="BunkPlus">+</span>
                    </div>

                </div>
                <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">Air Mates</label>
                    <div class="qty ">
                        <span class="minus bg-info MatesMinus" id="MatesMinus">-</span>
                        <input type="number" class="count MatesCount" id="MatesCount" name="mate" value="0">
                        <span class="plus bg-info MatesPlus" id="MatesPlus">+</span>
                    </div>

                </div>

                <div class="form-group col-md-12 d-flex label-config">
                    <label for="" class="col-d-3">Couch</label>
                    <div class="qty ">
                        <span class="minus bg-info CouchMinus" id="CouchMinus">-</span>
                        <input type="number" class="count CouchCount" id="CouchCount" name="couch" value="0">
                        <span class="plus bg-info CouchPlus" id="CouchPlus">+</span>
                    </div>

                </div>
                <div class="form-group float-right">
                    <button type="submit" class="btn btn-primary">Add</button>
                 </div>





            </div>

        </div>

         </form>
</div>
<?php
include 'footer.php';
?>
