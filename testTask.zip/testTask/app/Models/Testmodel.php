<?php

/**
 * Created by PhpStorm.
 * User: HP
 * Date: 9/29/2020
 * Time: 5:43 PM
 */
namespace App\Models;
use CodeIgniter\Model;
class Testmodel extends Model
{

   protected $DBGroup='default';
   protected $table='property';
   protected $primaryKey="propertyId";
   protected $returnType ='array';
   protected $useTimestamps=true;
   protected $allowedFields=['propertyType','owner','identificator_nab','country','street','apt','city','state','postcode','starting_date','owner_stays','compulsory_inclusions','guests','bedrooms','bathrooms'];

   public function insertData($data)
   {
       $db      = \Config\Database::connect();
       $builder = $db->table('bed_space');
       $result = $builder->insert($data);
       return $result;
   }

   public function getData()
   {
        $this->join('bed_space', 'property.propertyId = bed_space.propertyId' );
        $result = $this->findAll();
        return $result;
    }
   public function getDataSingle($id)
   {
        $this->join('bed_space', 'property.propertyId = bed_space.propertyId' );
        $this->where('property.propertyId',$id);
        $result = $this->find();
        return $result;
    }

    public function deleteBedSpace($id)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('bed_space');
        $builder->where('propertyId', $id);
        $result= $builder->delete();

        return $result;
    }

    public function updateBedSpace($data,$id)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('bed_space');

        $builder->where('propertyId', $id);
        $result=$builder->update($data);
        return $result;
    }






}