
$(document).ready(function(){
    $('#guestCount').prop('disabled', false);
    $(document).on('click','.guestPlus',function(){
        $('#guestCount').val(parseInt($('#guestCount').val()) + 1 );
    });
    $(document).on('click','.guestMinus',function(){
        $('#guestCount').val(parseInt($('#guestCount').val()) - 1 );
        if ($('#guestCount').val() <= 0) {
            $('#guestCount').val(0);
        }
    });

    $('#bathCount').prop('disabled', false);
    $(document).on('click','#bathPlus',function(){
        $('#bathCount').val(parseInt($('#bathCount').val()) + 1 );
    });
    $(document).on('click','#bathMinus',function(){
        $('#bathCount').val(parseInt($('#bathCount').val()) - 1 );
        if ($('#bathCount').val() <= 0) {
            $('#bathCount').val(0);
        }
    });
    $('#kingCount').prop('disabled', false);
    $(document).on('click','#kingPlus',function(){
        $('#kingCount').val(parseInt($('#kingCount').val()) + 1 );
    });
    $(document).on('click','#kingminus',function(){
        $('#kingCount').val(parseInt($('#kingCount').val()) - 1 );
        if ($('#kingCount').val() <= 0) {
            $('#kingCount').val(0);
        }
    });
    $('#queenCount').prop('disabled', false);
    $(document).on('click','#queenPlus',function(){
        $('#queenCount').val(parseInt($('#queenCount').val()) + 1 );
    });
    $(document).on('click','#queenMinus',function(){
        $('#queenCount').val(parseInt($('#queenCount').val()) - 1 );
        if ($('#queenCount').val() <= 0) {
            $('#queenCount').val(0);
        }
    });
    $('#doubleCount').prop('disabled', false);
    $(document).on('click','#doublePlus',function(){
        $('#doubleCount').val(parseInt($('#doubleCount').val()) + 1 );
    });
    $(document).on('click','#doubleMinus',function(){
        $('#doubleCount').val(parseInt($('#doubleCount').val()) - 1 );
        if ($('#doubleCount').val() <= 0) {
            $('#doubleCount').val(0);
        }
    });
    $('#singleCount').prop('disabled', false);
    $(document).on('click','#singlePlus',function(){
        $('#singleCount').val(parseInt($('#singleCount').val()) + 1 );
    });
    $(document).on('click','#singleMinus',function(){
        $('#singleCount').val(parseInt($('#singleCount').val()) - 1 );
        if ($('#singleCount').val() <= 0) {
            $('#singleCount').val(0);
        }
    });
    $('#SofaCount').prop('disabled', false);
    $(document).on('click','#sofaPlus',function(){
        $('#SofaCount').val(parseInt($('#SofaCount').val()) + 1 );
    });
    $(document).on('click','#sofaMinus',function(){
        $('#SofaCount').val(parseInt($('#SofaCount').val()) - 1 );
        if ($('#SofaCount').val() <= 0) {
            $('#SofaCount').val(0);
        }
    });
    $('#BunkCount').prop('disabled', false);
    $(document).on('click','#BunkPlus',function(){
        $('#BunkCount').val(parseInt($('#BunkCount').val()) + 1 );
    });
    $(document).on('click','#BunkMinus',function(){
        $('#BunkCount').val(parseInt($('#BunkCount').val()) - 1 );
        if ($('#BunkCount').val() <= 0) {
            $('#BunkCount').val(0);
        }
    });
    $('#MatesCount').prop('disabled', false);
    $(document).on('click','#MatesPlus',function(){
        $('#MatesCount').val(parseInt($('#MatesCount').val()) + 1 );
    });
    $(document).on('click','#MatesMinus',function(){
        $('#MatesCount').val(parseInt($('#MatesCount').val()) - 1 );
        if ($('#MatesCount').val() <= 0) {
            $('#MatesCount').val(0);
        }
    });
    $('#MatesCount').prop('disabled', false);
    $(document).on('click','#CouchPlus',function(){
        $('#CouchCount').val(parseInt($('#CouchCount').val()) + 1 );
    });
    $(document).on('click','#CouchMinus',function(){
        $('#CouchCount').val(parseInt($('#CouchCount').val()) - 1 );
        if ($('#CouchCount').val() <= 0) {
            $('#CouchCount').val(0);
        }
    });
});

/**
 * Created by HP on 9/29/2020.
 */
